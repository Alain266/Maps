/**
 * Retourne la config globale du projet
 * @returns {Array} config
 */
function getConfig()
{
    let config =  {
        "default_geoloc": {
            "name": "Ap formation",
            "latitude": '43.5839367985570',
            "longitude": '1.4024505114413461',
        },
        "zoom": 13
    }

    return config;
}

/**
 *  Retourne les stations de métros avec les iconMarkers
 * @returns []
 */
function getStations()
{
    let icon_sizes = [40, 40]

    let redIcon = L.icon({
        iconUrl: "./images/red_push_pin.png",
        iconSize: icon_sizes,
    });
    let yellowIcon = L.icon({
        iconUrl: "./images/yellow_push_pin.png",
        iconSize: icon_sizes,
    });


    return [
    {
        name: 'Station Basso Cambo',
        latitude: '43.570222480871934',
        longitude: '1.3927389509201422',
        line: "A",
        icon: redIcon
    },
    {
        name: 'Station Arènes',
        latitude: '43.59341036353955',
        longitude: '1.4184824354296777',
        line: "A",
        icon: redIcon
    },
    {
        name: 'Station Capitole',
        latitude: '43.60478253309785',
        longitude: '1.4455057842071395',
        line: "A",
        icon: redIcon
    },
    {
        name: 'Station Marengo - SNCF',
        latitude: '43.610994374586184',
        longitude: '1.4549872949317002',
        line: "A",
        icon: redIcon
    },
    {
        name: 'Station Balma - Gramont',
        latitude: '43.62901149396253',
        longitude: '1.4822431813504364',
        line: "A",
        icon: redIcon
    },
    {
        name: 'Station Borderouge',
        latitude: '43.64080509286292',
        longitude: '1.4527721130441282',
        line: "B",
        icon: yellowIcon
    },
    {
        name: 'Station Compans Caffarelli',
        latitude: '43.610984673253235',
        longitude: '1.4358144976998306',
        line: "B",
        icon: yellowIcon
    },
    {
        name: 'Station Carmes',
        latitude: '43.597867914889605',
        longitude: '1.4455294418785902',
        line: "B",
        icon: yellowIcon
    },
    {
        name: 'Station Saint-Agne - SNCF',
        latitude: '43.579716599525256',
        longitude: '1.4502202852094426',
        line: "B",
        icon: yellowIcon
    },
    {
        name: 'Station Ramonville',
        latitude: '43.555852908482166',
        longitude: '1.475967041877208',
        line: "B",
        icon: yellowIcon
    },
];

}

/**
 * Créer les markers leaflet pour les stations passées en paramètre
 * @param map
 * @param stations
 */
function createStationsMarkers(map, stations)
{
    stations.forEach((function(station) {
        L.marker([station.latitude, station.longitude], { icon : station.icon })
            .addTo(map)
            .bindTooltip(station.name, { permanent: false, direction: "left" });
    }));
}

/**
 * Gère le module du formulaire pour centrer sur un nouveau point
 * @param map
 * @param config
 */
function manageFormGeoloc(map, config)
{
    let latitude = document.querySelector('#form-geoloc #lat').value;
    let longitude = document.querySelector('#form-geoloc #lng').value;

    map.setView([latitude, longitude], config.zoom);

    setCoordinatesInStorage(latitude, longitude);
}

/**
 * Enregistre dans le localStorage les coordonnées reçues
 * @param latitude
 * @param longitude
 */
function setCoordinatesInStorage(latitude, longitude)
{
    localStorage.setItem('latitude', latitude);
    localStorage.setItem('longitude', longitude);
}
/**
 * Créer la map leaflet en prenant en compte les données de geoloc dans le storage
 *
 * @param config
 * @returns {*}
 */
function createMap(config)
{
    geoloc = !localStorage.getItem('latitude') && !localStorage.getItem('longitude')
        ? [config.default_geoloc.latitude, config.default_geoloc.longitude]
        : [localStorage.getItem('latitude'), localStorage.getItem('longitude')];

    let map = L.map("map").setView(geoloc, config.zoom);

    map.addLayer(L.tileLayer("http://{s}.tile.osm.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
    }));

    return map
}

function manageUserGeoloc(map, config)
{
    navigator.geolocation.getCurrentPosition((position) => {
        map.setView([position.coords.latitude, position.coords.longitude ], config.zoom);
        setCoordinatesInStorage(position.coords.latitude, position.coords.longitude);
    });
}

function manageEvents(map, config) {
    // 1 - User geoloc
    document.getElementById('user-geoloc').addEventListener('click', function(event) {
        manageUserGeoloc(map, config)
    });

    // 2 - Formulaire de localisation
    document.getElementById('form-geoloc').addEventListener('submit', function(event) {
        event.preventDefault();
        manageFormGeoloc(map, config)
    })
}

/**
 * Lancement
 */
function init() {
    let config = getConfig();
    let map = createMap(config);
    let stations = getStations();

    manageEvents(map, config);

    createStationsMarkers(map, stations);
}
